<?php
$servername  = "localhost";
$username = "id21546714_root";
$password = "Carrentalroot@1234";
$dbname = "id21546714_carrental";

$connect = mysqli_connect($servername, $username, $password, $dbname);

?>